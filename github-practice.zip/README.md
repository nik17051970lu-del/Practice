# Practice

Учебные работы по JavaScript и веб-дизайну.

- [Основы JavaScript](javascript-basics/README.md) — массивы, коллекции, рекурсия и контекст функций.
- [Практика DOM](dom-practice/README.md) — десять упражнений, включая список дел.
- [Запрос погоды](weather-api-practice/README.md) — запрос к API и разбор ответа JSON.
- [Практика веб-дизайна](web-design-practice/README.md) — визуальная иерархия, цветовая палитра и разбор макетов.

В каждой папке есть инструкции по запуску или описание задания.

[Исходные учебные примеры](https://github.com/elena20102023-design/my-first-repo).
