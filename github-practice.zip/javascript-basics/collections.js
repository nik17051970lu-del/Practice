// Задание 1

const siteA = ['anna', 'ivan', 'anna', 'petr', 'olga'];
const siteB = ['ivan', 'anna', 'sergey', 'olga', 'ivan'];
const setA = new Set(siteA);
console.log("Set сайта A:", setA);
console.log("Количество уникальных на сайте A:", setA.size);
console.log("Заходил ли 'petr':", setA.has('petr'));
const allVisitors = new Set([...siteA, ...siteB]);
const finalArray = [...allVisitors];
console.log("Итоговый массив:", finalArray);

// Задание 2

const phoneBook = new Map([
  ['Ivanov', '+7-900-111-22-33'],
  ['Petrova', '+7-900-444-55-66'],
  ['Sidorov', '+7-900-777-88-99'],
]);
const petrovaPhone = phoneBook.get('Petrova');
console.log('Номер Petrova:', petrovaPhone);
phoneBook.delete('Sidorov');
console.log('Итоговый размер справочника:', phoneBook.size);
console.log('Остался ли Sidorov?:', phoneBook.has('Sidorov'));
const namesArray = [...phoneBook.keys()];
console.log('Массив имен сотрудников:', namesArray);
phoneBook.forEach((phone, name) => {
    console.log(`${name}: ${phone}`);
});

// Задание 3

const students = [
  { name: 'Anna', grade: 5 },
  { name: 'Ivan', grade: 4 },
  { name: 'Anna', grade: 5 }, 
  { name: 'Petr', grade: 3 },
  { name: 'Olga', grade: 4 },
  { name: 'Ivan', grade: 4 }  
];
const stringifiedStudents = students.map(student => JSON.stringify(student));
const uniqueStringsSet = new Set(stringifiedStudents);
const uniqueStudents = Array.from(uniqueStringsSet, record => JSON.parse(record));
console.log("1. Уникальные студенты");
console.log(uniqueStudents);

const gradeMap = new Map();
students.forEach(student => {
  const { name, grade } = student;
  if (!gradeMap.has(grade)) {
    gradeMap.set(grade, []);
  }
  gradeMap.get(grade).push(name);
});

console.log("\n 2. Список студентов по оценкам");
for (const [grade, names] of gradeMap) {
  console.log(`Оценка ${grade}: ${names.join(', ')}`);
}
const uniqueGrades = [...gradeMap.keys()];
console.log("\nУникальные оценки:", uniqueGrades);
