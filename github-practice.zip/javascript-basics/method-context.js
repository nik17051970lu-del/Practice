function showInfo() {
  'use strict';
  console.log(this?.name, this?.group);
}

const students = [
  { name: 'Алина', group: 'ВЕБ-21', showInfo },
  { name: 'Максим', group: 'ВЕБ-22', showInfo },
];

for (const student of students) {
  student.showInfo();
}

const detachedShowInfo = students[0].showInfo;
detachedShowInfo();
