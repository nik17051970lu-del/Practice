const products = [
  { name: 'Ноутбук', price: 75000, category: 'Техника' },
  { name: 'Мышь', price: 1500, category: 'Аксессуары' },
  { name: 'Клавиатура', price: 3500, category: 'Аксессуары' },
  { name: 'Монитор', price: 22000, category: 'Техника' },
  { name: 'Наушники', price: 5000, category: 'Аксессуары' },
];

console.log('Каталог');
products.forEach(({ name, price }) => console.log(`${name} — ${price} руб.`));

console.log('Товары дешевле 5000 руб.', products.filter(({ price }) => price < 5000));
console.log('Названия товаров', products.map(({ name }) => name));
console.log('Первый товар из категории «Техника»', products.find(({ category }) => category === 'Техника'));
console.log('Цены со скидкой 10%', products.map(({ price }) => price * 0.9));

const accessoryNames = products
  .filter(({ category, price }) => category === 'Аксессуары' && price <= 4000)
  .map(({ name }) => name);

console.log('Аксессуары до 4000 руб. включительно', accessoryNames);
