# Основы JavaScript

- [29.10. Методы массивов](products.js) — выборка товаров, поиск и расчёт скидки.
- [30.10. Set и Map](collections.js) — уникальные посетители, справочник и оценки.
- [30.10. Рекурсия](recursion.js) — сумма чисел от 1 до n и целая неотрицательная степень.
- [Контекст метода](method-context.js) — обычный вызов и вызов через переменную.
- [Контекст и привязка](function-context.js) — потеря `this`, методы `call`, `apply` и `bind`.

Для запуска используйте Node.js, например `node products.js`.

[Исходные учебные примеры](https://github.com/elena20102023-design/my-first-repo/tree/ca7a592348c2cd8bf73d97ac30f6fd1707710736).
