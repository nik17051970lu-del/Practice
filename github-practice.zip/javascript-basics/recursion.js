function sumTo(n) {
  if (n === 0) {
    return 0;
  }

  return n + sumTo(n - 1);
}

function power(base, exponent) {
  if (exponent === 0) {
    return 1;
  }

  return base * power(base, exponent - 1);
}

for (const n of [1, 3, 5]) {
  console.log(`Сумма до ${n}: ${sumTo(n)}`);
}

for (const [base, exponent] of [[2, 0], [2, 3], [3, 2], [5, 3]]) {
  console.log(`${base} ^ ${exponent} = ${power(base, exponent)}`);
}
