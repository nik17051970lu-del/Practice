const title = document.getElementById('title');
const description = document.getElementById('description');
const changeButton = document.getElementById('change');

changeButton.addEventListener('click', () => {
  title.textContent = 'Добро пожаловать на практику!';
  description.textContent = 'Этот текст обновлён с помощью JavaScript.';
});
