const paragraph = document.querySelector('#paragraph');
const deleteButton = document.querySelector('#delete');

deleteButton.addEventListener('click', () => {
  paragraph.remove();
  deleteButton.disabled = true;
});
