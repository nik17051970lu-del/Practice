const heading = document.querySelector('#heading');

document.querySelector('#color').addEventListener('click', () => {
  heading.style.color = '#5b21b6';
});

document.querySelector('#background').addEventListener('click', () => {
  document.body.style.backgroundColor = '#ede9fe';
});
