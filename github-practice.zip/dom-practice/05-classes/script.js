const message = document.getElementById("message");
message.classList.add("active");
console.log("Есть ли класс active?", message.classList.contains("active"));
message.classList.remove("text");
setTimeout(() => {
    message.classList.add("hidden");
}, 2000);
