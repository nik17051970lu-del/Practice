const link = document.getElementById("link");
const currentHref = link.getAttribute("href");
console.log("1. Текущая ссылка (получили):", currentHref);
link.setAttribute("href", "https://yandex.ru");
console.log("2. Новая ссылка (изменили):", link.getAttribute("href"));
const hasTarget = link.hasAttribute("target");
console.log("3. Есть ли атрибут target? (проверили):", hasTarget);
link.removeAttribute("href");
console.log("4. Атрибут href после удаления:", link.getAttribute("href"));
