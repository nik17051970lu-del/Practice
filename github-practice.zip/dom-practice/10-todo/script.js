const taskForm = document.getElementById('taskForm');
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');
const counter = document.getElementById('counter');

function updateCounter() {
  counter.textContent = `Всего задач: ${taskList.children.length}`;
}

taskInput.addEventListener('input', () => taskInput.setCustomValidity(''));

taskForm.addEventListener('submit', event => {
  event.preventDefault();

  const taskText = taskInput.value.trim();
  if (!taskText) {
    taskInput.setCustomValidity('Введите текст задачи.');
    taskInput.reportValidity();
    return;
  }

  const item = document.createElement('li');
  const label = document.createElement('span');
  const deleteButton = document.createElement('button');

  label.textContent = taskText;
  deleteButton.type = 'button';
  deleteButton.textContent = 'Удалить';
  deleteButton.setAttribute('aria-label', `Удалить задачу «${taskText}»`);
  deleteButton.addEventListener('click', () => {
    item.remove();
    updateCounter();
    taskInput.focus();
  });

  item.append(label, deleteButton);
  taskList.append(item);
  taskForm.reset();
  updateCounter();
  taskInput.focus();
});
