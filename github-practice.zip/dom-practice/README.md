# Практика DOM

Откройте нужный `index.html` в браузере. В первых пяти примерах результат виден в консоли разработчика.

| Упражнение | Страница |
| --- | --- |
| Поиск элементов и объекты браузера | [01-selectors](01-selectors/index.html) |
| Навигация по DOM | [02-navigation](02-navigation/index.html) |
| Атрибуты ссылок | [03-attributes](03-attributes/index.html) |
| Свойства элементов | [04-properties](04-properties/index.html) |
| Добавление и удаление CSS-классов | [05-classes](05-classes/index.html) |
| Изменение текста | [06-text](06-text/index.html) |
| Изменение цвета текста и фона | [07-colors](07-colors/index.html) |
| Создание элементов списка | [08-list](08-list/index.html) |
| Удаление абзаца | [09-remove](09-remove/index.html) |
| Итоговый проект. Список дел | [10-todo](10-todo/index.html) |

[Исходные учебные примеры](https://github.com/elena20102023-design/my-first-repo/tree/ca7a592348c2cd8bf73d97ac30f6fd1707710736).
