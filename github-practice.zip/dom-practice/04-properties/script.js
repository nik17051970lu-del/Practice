const input = document.getElementById("username");
const resultParagraph = document.getElementById("result");
console.log("Было введено:", input.value);
input.value = "Участник практики";
resultParagraph.textContent = "Результат: " + input.value;
