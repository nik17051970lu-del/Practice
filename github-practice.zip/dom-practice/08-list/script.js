const skills = document.querySelector('#skills');

for (const name of ['HTML', 'CSS', 'JavaScript']) {
  const item = document.createElement('li');
  item.textContent = name;
  skills.append(item);
}
