const first = document.querySelector("#first");
const parent = first.parentElement;
console.log(parent);
console.log(parent.children);
console.log(parent.firstElementChild);
console.log(parent.lastElementChild);
console.log(first.nextElementSibling);


const third = document.querySelector("#third");
console.log(third.previousElementSibling);
