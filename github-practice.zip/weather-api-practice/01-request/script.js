async function getWeather() {
  const status = document.querySelector('#status');
  status.textContent = 'Запрашиваем погоду…';

  try {
    const response = await fetch('https://wttr.in/Moscow?format=j1');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log(data);
    status.textContent = 'Ответ получен.';
  } catch (error) {
    status.textContent = 'Не удалось получить погоду. Попробуйте обновить страницу.';
    console.error('Ошибка запроса погоды:', error);
  }
}

getWeather();
