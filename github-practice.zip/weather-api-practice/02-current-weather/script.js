async function getWeather() {
  const status = document.querySelector('#status');
  status.textContent = 'Запрашиваем погоду…';

  try {
    const response = await fetch('https://wttr.in/Moscow?format=j1');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    const [current] = data.current_condition ?? [];
    if (!current) {
      throw new Error('В ответе отсутствуют текущие условия.');
    }

    const description = current.lang_ru?.[0]?.value ?? current.weatherDesc?.[0]?.value ?? 'нет описания';
    console.log(`Температура: ${current.temp_C}°C`);
    console.log(`Влажность: ${current.humidity}%`);
    console.log(`Погода: ${description}`);
    status.textContent = 'Ответ получен.';
  } catch (error) {
    status.textContent = 'Не удалось получить погоду. Попробуйте обновить страницу.';
    console.error('Ошибка запроса погоды:', error);
  }
}

getWeather();
